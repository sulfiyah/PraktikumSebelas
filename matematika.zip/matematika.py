phi = 3.14

def luas_lingkaran():
  r = float(input("Masukkan jari-jari lingkaran: "))
  return phi * r * r

def luas_persegi():
  s = float(input("Masukkan sisi persegi: "))
  return s * s

def luas_persegipanjang():
  p = float(input("Masukkan panjang persegi panjang: "))
  l = float(input("Masukkan lebar persegi panjang: "))
  return p * l
